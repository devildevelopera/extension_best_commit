// chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
//     alert('updated from contentscript');
//     // send message to background script
//     chrome.runtime.sendMessage({ "newText": '00' });
// });

